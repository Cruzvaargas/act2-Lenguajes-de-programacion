/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    float num1 =0.0;
    float num2 =0.0;
    float resultadosum;
    float resultadores;
    float resultadomul;
    float resultadodiv;
    
    
    cout<<"escribe el primer digito  ";
    cin>>num1;
    cout<<"escribe el segundo digito  ";
    cin>>num2;
    
    resultadosum = num1 + num2;
    resultadores = num1 - num2;
    resultadomul = num1 * num2;
   
    
    cout<<"el resultado de la suma es  "<<resultadosum<<endl;
    cout<<"el resultado de la resta es  "<<resultadores<<endl;
    cout<<"el resultado de la multiplicacion es  "<<resultadomul<<endl;
    if(num2!=0){ 
       resultadodiv = num1 / num2;
        
    } 
    
    else { 
        
     cout<< "No se puede dividir entre cero. "<<endl;
   return 1;
}  cout<<"el resultado de la division es  "<<resultadodiv<<endl;
    
    return 0;
}
